const state = {
  powerOn: false,
  selectedColor: '#ff3333',
  selectedType: 'L',
  selectedTerminal: null,
  wires: [],
  switches: {
    sw1: false
  }
};

const canvas = document.getElementById('wireCanvas');
const ctx = canvas.getContext('2d');

function resizeCanvas() {
  const workbench = document.getElementById('workbench');
  canvas.width = workbench.clientWidth;
  canvas.height = workbench.clientHeight;
  drawWires();
}

window.addEventListener('resize', resizeCanvas);
setTimeout(resizeCanvas, 100);

document.querySelectorAll('.term').forEach(term => {
  term.addEventListener('click', (e) => {
    e.stopPropagation();
    const termId = term.getAttribute('data-id');

    if (!state.selectedTerminal) {
      state.selectedTerminal = termId;
      term.classList.add('selected');
      updateStatus(`تم اختيار النقطة (${termId}). اضغط على النقطة الثانية لتوصيل السلك.`, 'info');
    } else {
      if (state.selectedTerminal !== termId) {
        state.wires.push({
          from: state.selectedTerminal,
          to: termId,
          color: state.selectedColor,
          type: state.selectedType
        });
        updateStatus(`تم توصيل السلك بين (${state.selectedTerminal}) و (${termId}).`, 'info');
        runSimulation();
      }
      document.querySelectorAll('.term').forEach(t => t.classList.remove('selected'));
      state.selectedTerminal = null;
      drawWires();
    }
  });
});

function getTerminalPos(id) {
  const el = document.querySelector(`[data-id="${id}"]`);
  if (!el) return { x: 0, y: 0 };
  const rect = el.getBoundingClientRect();
  const benchRect = document.getElementById('workbench').getBoundingClientRect();
  return {
    x: rect.left + rect.width / 2 - benchRect.left,
    y: rect.top + rect.height / 2 - benchRect.top
  };
}

function drawWires() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  state.wires.forEach(wire => {
    const p1 = getTerminalPos(wire.from);
    const p2 = getTerminalPos(wire.to);

    ctx.beginPath();
    ctx.moveTo(p1.x, p1.y);
    const midY = (p1.y + p2.y) / 2;
    ctx.bezierCurveTo(p1.x, midY, p2.x, midY, p2.x, p2.y);

    ctx.strokeStyle = wire.color;
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    
    if (state.powerOn && (wire.type === 'L' || wire.isPowered)) {
      ctx.shadowColor = wire.color;
      ctx.shadowBlur = 8;
    } else {
      ctx.shadowBlur = 0;
    }

    ctx.stroke();
  });
}

document.querySelectorAll('.wire-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.wire-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.selectedColor = btn.getAttribute('data-color');
    state.selectedType = btn.getAttribute('data-type');
  });
});

const powerBtn = document.getElementById('btn-power');
powerBtn.addEventListener('click', () => {
  state.powerOn = !state.powerOn;
  if (state.powerOn) {
    powerBtn.innerText = '⚡ إيقاف الكهرباء (OFF)';
    powerBtn.classList.add('off');
  } else {
    powerBtn.innerText = '⚡ تشغيل الكهرباء (ON)';
    powerBtn.classList.remove('off');
  }
  runSimulation();
});

const sw1Btn = document.getElementById('sw1-toggle');
sw1Btn.addEventListener('click', () => {
  state.switches.sw1 = !state.switches.sw1;
  sw1Btn.innerText = state.switches.sw1 ? 'فتح المفتاح (ON)' : 'إغلاق المفتاح (OFF)';
  runSimulation();
});

document.getElementById('btn-reset').addEventListener('click', () => {
  state.wires = [];
  state.powerOn = false;
  powerBtn.innerText = '⚡ تشغيل الكهرباء (ON)';
  powerBtn.classList.remove('off');
  drawWires();
  runSimulation();
  updateStatus('تم مسح جميع الأسلاك وإعادة الضبط.', 'info');
});

function runSimulation() {
  const bulb1 = document.getElementById('bulb1-icon');
  bulb1.classList.remove('on');

  if (!state.powerOn) {
    drawWires();
    return;
  }

  const hasLtoSW = isConnected('L_IN', 'SW1_IN');
  const hasSWtoBulb = isConnected('SW1_OUT', 'BULB1_L');
  const hasNtoBulb = isConnected('N_IN', 'BULB1_N');

  if (isConnected('L_IN', 'N_IN')) {
    updateStatus('🚨 خطأ شورت (Short Circuit)! تم التوصيل بين الفاز والمحايد مباشرة. فصل القاطع تلقائياً!', 'danger');
    state.powerOn = false;
    powerBtn.innerText = '⚡ تشغيل الكهرباء (ON)';
    powerBtn.classList.remove('off');
    drawWires();
    return;
  }

  if (hasLtoSW && hasSWtoBulb && hasNtoBulb) {
    if (state.switches.sw1) {
      bulb1.classList.add('on');
      updateStatus('✅ الدائرة تعمل بنجاح! المصباح يضيء بشكل ممتاز.', 'success');
    } else {
      updateStatus('⚡ الدائرة مكتملة والتغذية واصلة للمفتاح. قم بتشغيل المفتاح لإضاءة المصباح.', 'info');
    }
  } else {
    updateStatus('⚠️ الدائرة غير مكتملة. تأكد من توصيل الفاز للمفتاح والراجع للمصباح والمحايد للمصباح.', 'info');
  }

  drawWires();
}

function isConnected(start, target, visited = new Set()) {
  if (start === target) return true;
  visited.add(start);

  for (let wire of state.wires) {
    let nextNode = null;
    if (wire.from === start) nextNode = wire.to;
    if (wire.to === start) nextNode = wire.from;

    if (nextNode && !visited.has(nextNode)) {
      if (isConnected(nextNode, target, visited)) return true;
    }
  }
  return false;
}

function updateStatus(msg, type) {
  const box = document.getElementById('status-box');
  box.innerText = msg;
  box.className = `status-box ${type}`;
}
